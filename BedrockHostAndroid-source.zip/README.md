# Bedrock Host Android — proyecto base

Este es un **esqueleto de Android Studio**, no un APK terminado ni un servidor funcional listo para publicar.

## Qué incluye
- Kotlin + Jetpack Compose.
- Pantalla inicial con controles, consola y campo de comandos.
- Foreground Service, notificación persistente y WakeLock limitado.
- Lanzador de proceso preparado para `files/servers/start-server.sh`.

## Limitaciones importantes
- No se incluye PocketMine-MP, Nukkit, PHP, Java runtime ni binarios ARM.
- El panel aún no recibe el estado real del proceso; la consola visible es una interfaz inicial.
- PocketMine-MP requiere PHP compatible con Android/ARM y sus extensiones. No basta con copiar el código PHP.
- Nukkit requiere un runtime Java compatible en Android y verificar las limitaciones de sockets/UDP.
- `MANAGE_EXTERNAL_STORAGE` no se concede automáticamente y normalmente no es necesario: usa almacenamiento privado de la app o el Storage Access Framework.
- Android moderno puede restringir los servicios en segundo plano y los procesos largos. Un Foreground Service no garantiza que el fabricante no mate el proceso.
- Abrir UDP 19132 en un router no siempre funciona (CGNAT del proveedor puede impedir conexiones externas).

## Estructura
```
BedrockHost/
  settings.gradle.kts
  build.gradle.kts
  gradle.properties
  app/
    build.gradle.kts
    src/main/AndroidManifest.xml
    src/main/java/com/example/bedrockhost/
      MainActivity.kt
      ServerService.kt
```

## Compilar APK debug
1. Instala Android Studio y un JDK 17.
2. Abre esta carpeta como proyecto.
3. Deja que Gradle sincronice y resuelva dependencias.
4. Ejecuta **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. El APK debug aparece en `app/build/outputs/apk/debug/app-debug.apk`.

Para compilar por terminal en un entorno con Android SDK:
```
gradle assembleDebug
```

## Antes de usarlo con un servidor real
1. Obtén el núcleo y runtime desde sus fuentes oficiales y revisa licencias e integridad.
2. Implementa instalación/actualización segura del runtime y servidor.
3. Ajusta `ServerService.kt` a la forma exacta de lanzar el runtime instalado.
4. Añade lectura de stdout a un `StateFlow`/Binder para mostrar consola real y manejo de errores.
5. Prueba en el dispositivo real, incluyendo apagado de pantalla, cambio de red y Android 13+.
