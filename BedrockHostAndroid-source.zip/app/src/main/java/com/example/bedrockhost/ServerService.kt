package com.example.bedrockhost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.io.BufferedWriter
import java.io.File
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

/**
 * Service scaffold. It deliberately does not start an arbitrary downloaded executable.
 * Supply a trusted, Android-compatible server runtime and adapt launch arguments first.
 */
class ServerService : Service() {
    private val executor = Executors.newSingleThreadExecutor()
    private var process: Process? = null
    private var stdin: BufferedWriter? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForeground(NOTIFICATION_ID, notification("Preparando servidor"))
                startServerProcess()
            }
            ACTION_COMMAND -> {
                val command = intent.getStringExtra(EXTRA_COMMAND).orEmpty()
                if (command.isNotBlank()) executor.execute {
                    try { stdin?.apply { write(command); newLine(); flush() } }
                    catch (_: Exception) { }
                }
            }
            ACTION_STOP -> {
                stopServerProcess()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startServerProcess() {
        if (process?.isAlive == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BedrockHost:Server").apply {
            setReferenceCounted(false)
            acquire(6 * 60 * 60 * 1000L)
        }

        executor.execute {
            try {
                val serverDir = File(filesDir, "servers")
                val launchScript = File(serverDir, "start-server.sh")
                if (!launchScript.exists()) {
                    updateNotification("Falta files/servers/start-server.sh")
                    return@execute
                }
                // Only run a user-installed, trusted script from app-private storage.
                // A compatible Android/ARM runtime must be installed separately.
                val pb = ProcessBuilder("/system/bin/sh", launchScript.absolutePath)
                    .directory(serverDir)
                    .redirectErrorStream(true)
                process = pb.start()
                stdin = BufferedWriter(OutputStreamWriter(process!!.outputStream))
                process!!.inputStream.bufferedReader().useLines { lines ->
                    lines.forEach { line -> updateNotification(line.take(100)) }
                }
            } catch (e: Exception) {
                updateNotification("Error: ${e.javaClass.simpleName}")
            } finally {
                stdin = null
                process = null
                releaseWakeLock()
            }
        }
    }

    private fun stopServerProcess() {
        executor.execute {
            try {
                stdin?.apply { write("stop"); newLine(); flush() }
                Thread.sleep(1200)
            } catch (_: Exception) { }
            process?.destroy()
            if (process?.isAlive == true) process?.destroyForcibly()
            process = null
            stdin = null
            releaseWakeLock()
        }
    }

    private fun releaseWakeLock() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) { }
        wakeLock = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Servidor Minecraft", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Bedrock Host")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, notification(message))
    }

    override fun onDestroy() {
        stopServerProcess()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.example.bedrockhost.START"
        const val ACTION_STOP = "com.example.bedrockhost.STOP"
        const val ACTION_COMMAND = "com.example.bedrockhost.COMMAND"
        const val EXTRA_COMMAND = "command"
        private const val CHANNEL_ID = "bedrock_host_server"
        private const val NOTIFICATION_ID = 19132
    }
}
