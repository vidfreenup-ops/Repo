package com.example.bedrockhost

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val requestNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { BedrockHostScreen(
            onStart = { startServer() },
            onStop = { stopServer() },
            onCommand = { command ->
                val intent = Intent(this, ServerService::class.java)
                    .setAction(ServerService.ACTION_COMMAND)
                    .putExtra(ServerService.EXTRA_COMMAND, command)
                startService(intent)
            }
        ) }
    }

    private fun startServer() {
        ContextCompat.startForegroundService(
            this, Intent(this, ServerService::class.java).setAction(ServerService.ACTION_START)
        )
    }

    private fun stopServer() {
        startService(Intent(this, ServerService::class.java).setAction(ServerService.ACTION_STOP))
    }
}

@Composable
private fun BedrockHostScreen(
    onStart: () -> Unit,
    onStop: () -> Unit,
    onCommand: (String) -> Unit
) {
    var running by remember { mutableStateOf(false) }
    var command by remember { mutableStateOf("") }
    var console by remember { mutableStateOf(listOf(
        "Bedrock Host listo.",
        "Coloca un servidor compatible en files/servers/ antes de iniciar.",
        "Este proyecto no incluye binarios del servidor."
    )) }

    MaterialTheme {
        Scaffold { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Bedrock Host", style = MaterialTheme.typography.headlineMedium)
                Text(if (running) "Estado: iniciado (solicitud enviada)" else "Estado: detenido")
                Text("Puerto esperado: UDP 19132")
                Text("Jugadores: —  |  RAM: —")
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { running = true; onStart() }, enabled = !running) {
                        Text("Iniciar")
                    }
                    OutlinedButton(onClick = { running = false; onStop() }, enabled = running) {
                        Text("Detener")
                    }
                }
                Text("Consola", style = MaterialTheme.typography.titleMedium)
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(console) { line -> Text(line, style = MaterialTheme.typography.bodySmall) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = command,
                        onValueChange = { command = it },
                        modifier = Modifier.weight(1f),
                        label = { Text("Comando") },
                        singleLine = true
                    )
                    Button(onClick = {
                        val value = command.trim()
                        if (value.isNotEmpty()) {
                            onCommand(value)
                            console = (console + "> $value").takeLast(300)
                            command = ""
                        }
                    }) { Text("Enviar") }
                }
                Text(
                    "Nota: esta versión base todavía no incorpora el runtime ni el núcleo de PocketMine/Nukkit. " +
                    "El estado y la consola son una interfaz inicial; no simulan un servidor real.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
